import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { NotificationModule } from './notification.module';
import { ClientsModule, Transport } from '@nestjs/microservices';
// @Module({
//   imports: [NotificationModule],
//   // controllers: [AppController],
//   // providers: [NotificationService],
// })
@Module({
  imports: [
    ClientsModule.register([
      {
        name: 'USER_SERVICE',
        transport: Transport.RMQ,
        options: {
          urls: ['amqp://guest:guest@rabbitmq:5672'],
          queue: 'user_created_queue',
          queueOptions: {
            durable: false,
          },
        },
      },
    ]),
  ],
})
export class AppModule {}

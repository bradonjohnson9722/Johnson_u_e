import { Injectable } from '@nestjs/common';
import { EventPattern, MessagePattern,Payload } from '@nestjs/microservices';
import * as nodemailer from 'nodemailer';

@Injectable()
export class NotificationService {
  @EventPattern('user_created')
  async handleUserCreated(@Payload() user: any) {
    console.log('New User Created:', user);
    
    // Simulate sending an email
    // const transporter = nodemailer.createTransport({
    //   service: 'gmail',
    //   auth: {
    //     user: 'your-email@gmail.com',
    //     pass: 'your-email-password',
    //   },
    // });

    // await transporter.sendMail({
    //   from: 'your-email@gmail.com',
    //   to: user.email,
    //   subject: 'Welcome to Our Service!',
    //   text: `Hello ${user.name}, welcome to our service!`,
    // });

    console.log(`Email sent to ${user.email}`);
  }
}

import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from '../user.entity';
import { Client, ClientProxy, Transport } from '@nestjs/microservices';

@Injectable()
export class UserService {
    @Client({ transport: Transport.RMQ, options: { urls: ['amqp://guest:guest@rabbitmq:5672'], queue: 'user_created_queue' } })
    private client: ClientProxy;
    constructor(
        @InjectRepository(User)
        private readonly userRepository: Repository<User>,
    ) { }

    async create(user: User): Promise<User> {
        const createdUser = await this.userRepository.save(user);
        console.log('createUser...', createdUser)
        this.client.emit('user_created', createdUser); // Publish the event
        return createdUser;
    }

    findAll(): Promise<User[]> {
        return this.userRepository.find();
    }

    findOne(id: number): Promise<User> {
        return this.userRepository.findOne({ where: { id } });
    }

    async update(id: number, user: User): Promise<User> {
        await this.userRepository.update(id, user);
        return this.userRepository.findOne({ where: { id } });
    }

    async remove(id: number): Promise<void> {
        await this.userRepository.delete(id);
    }
}
